#include "text_box_entity.h"

namespace bejeweled
{
	void TextBoxEntity::OnStart(SDL_Renderer* g_renderer)
	{
		std::string font = "pixel_font";
		texture = TextureManager::GetInstance().CreateTexture(g_renderer, background_text, background_text);
		fillrect = { x_pos_index * TILE_PIXEL_SIZE, y_pos_index * TILE_PIXEL_SIZE, x_size, y_size };
		UpdateText(g_renderer, text);
	}

	void TextBoxEntity::OnRender(SDL_Renderer* g_renderer, int last_frame_duration)
	{
		// Render the background texture first
		Render(g_renderer, texture->SDLTexture(), fillrect, TILE_PIXEL_SIZE);

		// Render the text after
		Render(g_renderer, text_texture->SDLTexture(), textrect, TILE_PIXEL_SIZE);
	}

	void TextBoxEntity::UpdateText(SDL_Renderer* g_renderer, std::string new_text)
	{
		std::string font = "pixel_font";
		if (new_text.compare(text) != 0)
		{
			TextureManager::GetInstance().DestroyTexture(text + font);
		}
		this->text = new_text;
		text_texture = TextureManager::GetInstance().CreateTextTexture(g_renderer, font, text, text + font);

		int pixel_outline = 10;
		float aspect_ratio = (float)text_texture->Width() / text_texture->Height();

		int text_width = 0;
		int text_height = 0;

		text_height = y_size - pixel_outline;
		text_width = (int)(text_height * aspect_ratio);

		if (text_width > x_size)
		{
			text_width = x_size - pixel_outline;
			text_height = (int)(text_width / aspect_ratio);
		}

		textrect = { x_pos_index * TILE_PIXEL_SIZE + (int)(x_size * 0.5f) - (int)(text_width * 0.5f), y_pos_index * TILE_PIXEL_SIZE - (int)(y_size * 0.5f) + (int)(text_height * 0.5f), text_width, text_height };
	}
}