#pragma once

#include <memory>
#include <SDL.h>
#include "renderable.h"
#include "tile_entity.h"
#include "text_box_entity.h"
#include "extensions.h"
#include "text_entity.h"
#include "bar_entity.h"

namespace bejeweled
{
	/*
		Contains all the different ui elements present in the game.
	*/
	class UiController : public Renderable
	{
		// Selector piece that is rendered when the user clicks a piece with the mouse.
		std::shared_ptr<PieceEntity> selector;

		// Score name.
		std::shared_ptr<TextBoxEntity> score_text;

		// Score text updated constantly.
		std::shared_ptr<TextEntity> score;

		// Timer name.
		std::shared_ptr<TextBoxEntity> timer_text;

		// Timer value updated constantly.
		std::shared_ptr<TextBoxEntity> timer;

		// Text to display when the game over condition has been achieved in the game manager.
		std::shared_ptr<TextEntity> game_over_text;

		// Restart text.
		std::shared_ptr<TextEntity> click_to_restart;

		// Score bar that scales up as we reach the victory score goal.
		std::shared_ptr<BarEntity> bar;

		bool game_over;

	public:
		UiController();
		~UiController() {}

		void OnStart(SDL_Renderer* g_renderer);
		void OnRender(SDL_Renderer* g_renderer, int last_frame_duration);

		void Select(std::shared_ptr<TileEntity> tile);
		void Deselect();

		void UpdateScore(SDL_Renderer* g_renderer, int score_value);
		void UpdateTimer(SDL_Renderer* g_renderer, int timer_value);

		void GameOver(SDL_Renderer* g_renderer, int score_value);
		void Restart();
	};
}