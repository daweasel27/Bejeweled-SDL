#pragma once

namespace bejeweled 
{
	const int SCREEN_WIDTH = 640;
	const int SCREEN_HEIGHT = 512;

	const int TILE_PIXEL_SIZE = 64;
	const int HALF_TILE_PIXEL_SIZE = 32;

	// We create a window of size WIDTH and HEIGHT with the following extra margins.
	const int MARGIN_X = TILE_PIXEL_SIZE * 3;
	const int MARGIN_Y = TILE_PIXEL_SIZE * 2;

	const int MAP_TILE_SIZE_X = 8;
	const int MAP_TILE_SIZE_Y = 8;

	const int TOTAL_TILE_COUNT = MAP_TILE_SIZE_X * MAP_TILE_SIZE_Y;

	// When a piece is destroyed this is the amount of score it gives.
	const int SCORE_PER_PIECE = 100;

	const int TIME = 200;
	const int VICTORY_SCORE = 20000;

	// Offset applied to every 2d entity, works like a camera moving the world by OFFSET amount.
	const int OFFSET_X = TILE_PIXEL_SIZE;
	const int OFFSET_Y = TILE_PIXEL_SIZE;
}