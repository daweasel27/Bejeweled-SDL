#pragma once

#include "quad_entity.h"
#include "text_texture.h"
#include "texture_manager.h"
#include "math.h"
#include "extensions.h"

namespace bejeweled
{
	/*
		Renders the scaling texture acording to the amount of score we have left to achieve.
	*/
	class BarEntity : public QuadEntity
	{
		std::shared_ptr<Texture> back_texture;
		SDL_Rect backrect;
	public:

		BarEntity(int x, int y, int x_size, int y_size) :
			QuadEntity(x, y, x_size, y_size) {}

		~BarEntity() {}

		void OnStart(SDL_Renderer* g_renderer);
		void OnRender(SDL_Renderer* g_renderer, int last_frame_duration);

		// Scales the current texture.
		void Scale(float scale);
	};
}