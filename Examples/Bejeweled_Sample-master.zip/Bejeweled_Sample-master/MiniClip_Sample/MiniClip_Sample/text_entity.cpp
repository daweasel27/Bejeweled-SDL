#include "text_entity.h"

namespace bejeweled
{
	void TextEntity::OnStart(SDL_Renderer* g_renderer)
	{
		std::string font = "pixel_font";
		fillrect = { x_pos_index * TILE_PIXEL_SIZE, y_pos_index * TILE_PIXEL_SIZE, x_size, y_size };
		UpdateText(g_renderer, text);
	}

	void TextEntity::OnRender(SDL_Renderer* g_renderer, int last_frame_duration)
	{
		// Render the text
		Render(g_renderer, texture->SDLTexture(), fillrect, TILE_PIXEL_SIZE);
	}

	void TextEntity::UpdateText(SDL_Renderer* g_renderer, std::string new_text)
	{
		std::string font = "pixel_font";
		if (new_text.compare(text) != 0)
		{
			TextureManager::GetInstance().DestroyTexture(text + font);
		}
		this->text = new_text;
		texture = TextureManager::GetInstance().CreateTextTexture(g_renderer, font, text, text + font);

		float aspect_ratio = (float)texture->Width() / texture->Height();

		int text_width = 0;
		int text_height = 0;

		text_height = y_size;
		text_width = (int)(text_height * aspect_ratio);

		if (text_width > x_size)
		{
			text_width = x_size;
			text_height = (int)(text_width / aspect_ratio);
		}

		fillrect = { x_pos_index * TILE_PIXEL_SIZE + (int)(x_size * 0.5f) - (int)(text_width * 0.5f), y_pos_index * TILE_PIXEL_SIZE - (int)(y_size * 0.5f) + (int)(text_height * 0.5f), text_width, text_height };
	}
}