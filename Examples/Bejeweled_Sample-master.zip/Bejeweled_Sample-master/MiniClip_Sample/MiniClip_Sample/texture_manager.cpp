#include "texture_manager.h"

namespace bejeweled 
{
	std::shared_ptr<Texture> TextureManager::Texture(std::string filename)
	{
		auto iter = textures.find(filename);
		if (iter == textures.end())
		{
			return nullptr;
		}
		else
		{
			return iter->second;
		}
	}

	std::shared_ptr<Texture> TextureManager::CreateTexture(SDL_Renderer* g_renderer, std::string filename, std::string id)
	{
		auto iter = Texture(id);
		if (iter != nullptr)
		{
			return iter;
		}
		else
		{
			auto t = std::make_shared<bejeweled::Texture>();
			t->LoadFromFile(g_renderer, filename + ".png");
			textures.emplace(id, t);
			return textures.at(id);
		}
	}

	std::shared_ptr<Texture> TextureManager::CreateTextTexture(SDL_Renderer* g_renderer, std::string font, std::string text, std::string id)
	{
		auto iter = Texture(id);
		if (iter != nullptr)
		{
			return iter;
		}
		else
		{
			std::shared_ptr<bejeweled::Texture> t = std::make_shared<TextTexture>(text);
			t->LoadFromFile(g_renderer, font + ".ttf");
			textures.emplace(id, t);
			return textures.at(id);
		}
	}

	void TextureManager::DestroyTexture(std::string id)
	{
		textures.erase(id);
	}
}