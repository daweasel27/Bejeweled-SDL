#include "effects_controller.h"

namespace bejeweled
{
	void EffectsController::OnStart(SDL_Renderer* g_renderer)
	{
		for (std::shared_ptr<ExplosionEntity> explosion : effects)
		{
			explosion->OnStart(g_renderer);
		}
	}

	void EffectsController::OnRender(SDL_Renderer* g_renderer, int last_frame_duration)
	{
		std::vector<std::shared_ptr<ExplosionEntity>> to_remove = {};

		for (std::shared_ptr<ExplosionEntity> explosion : effects)
		{
			if (explosion->Finished())
			{
				to_remove.push_back(explosion);
			}
			else explosion->OnRender(g_renderer, last_frame_duration);
		}

		for (std::shared_ptr<ExplosionEntity> explosion : to_remove)
		{
			effects.erase(std::remove(effects.begin(), effects.end(), explosion), effects.end());
		}
	}

	void EffectsController::CreateExplosion(SDL_Renderer* g_renderer, std::shared_ptr<TileEntity> tile)
	{
		assert(tile->HasPiece());
		std::shared_ptr<ExplosionEntity> explosion = std::make_shared<ExplosionEntity>(tile->X(), tile->Y(), TILE_PIXEL_SIZE, tile->Piece()->PieceID());
		explosion->OnStart(g_renderer);
		effects.push_back(explosion);
	}

	void EffectsController::CreateScoreExplosion(SDL_Renderer* g_renderer, std::shared_ptr<TileEntity> tile, int num_pieces)
	{
		std::shared_ptr<ExplosionEntity> explosion = std::make_shared<ScoreExplosionEntity>(tile->X(), tile->Y(), TILE_PIXEL_SIZE, 0, ToString(num_pieces * SCORE_PER_PIECE));
		explosion->OnStart(g_renderer);
		effects.push_back(explosion);
	}
}