#pragma once

#include <SDL.h>
#include <memory>
#include "constants.h"
#include "renderable.h"
#include "texture.h"

namespace bejeweled 
{
	/*
		Generic class representing a 2D rectangle.
	*/
	class QuadEntity : public Renderable
	{
	protected:
		// Starting position indexes
		int x_pos_index;
		int y_pos_index;

		// Size in pixels
		int x_size;
		int y_size;

		std::shared_ptr<Texture> texture;

		// Final size in pixels.
		SDL_Rect fillrect;
		// Original texture size and location where to get the color information.
		SDL_Rect originrect;

	public:
		QuadEntity(int x, int y, int x_size, int y_size) : x_pos_index(x), y_pos_index(y), x_size(x_size), y_size(y_size) {}
		virtual ~QuadEntity() {}

		virtual void OnStart(SDL_Renderer* g_renderer) {}
		virtual void OnRender(SDL_Renderer* g_renderer, int last_frame_duration) {}
	};
}