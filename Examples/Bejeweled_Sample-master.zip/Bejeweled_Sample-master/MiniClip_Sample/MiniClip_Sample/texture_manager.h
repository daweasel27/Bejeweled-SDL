#pragma once

#include <memory>  
#include <unordered_map>
#include "texture.h"
#include "text_texture.h"

namespace bejeweled 
{
	/*
		Stores all existing textures, manages creation of textures
	*/
	class TextureManager
	{

		std::unordered_map<std::string, std::shared_ptr<Texture>> textures;

		TextureManager() : textures{} {}
	public:
		~TextureManager() {}

		static TextureManager& GetInstance()
		{
			static TextureManager texture_manager;
			return texture_manager;
		}

		std::shared_ptr<Texture> CreateTexture(SDL_Renderer* g_renderer, std::string filename, std::string id);
		std::shared_ptr<Texture> CreateTextTexture(SDL_Renderer* g_renderer, std::string font, std::string text, std::string id);
		std::shared_ptr<Texture> Texture(std::string filename);
		void DestroyTexture(std::string id);
	};
}