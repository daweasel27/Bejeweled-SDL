#include "bar_entity.h"

namespace bejeweled
{
	void BarEntity::OnStart(SDL_Renderer* g_renderer)
	{
		texture = TextureManager::GetInstance().CreateTexture(g_renderer, "bar", "bar");
		back_texture = TextureManager::GetInstance().CreateTexture(g_renderer, "bar_background", "bar_background");
		backrect = { x_pos_index * TILE_PIXEL_SIZE, y_pos_index * TILE_PIXEL_SIZE, x_size, y_size };
		fillrect = backrect;
		originrect = { 0, 0, texture->Width(), texture->Height() };
	}

	void BarEntity::OnRender(SDL_Renderer* g_renderer, int last_frame_duration)
	{
		// Red texture
		Render(g_renderer, texture->SDLTexture(), fillrect, originrect, TILE_PIXEL_SIZE);
		// Outline
		Render(g_renderer, back_texture->SDLTexture(), backrect, TILE_PIXEL_SIZE);
	}

	void BarEntity::Scale(float scale)
	{
		fillrect = { x_pos_index * TILE_PIXEL_SIZE, y_pos_index * TILE_PIXEL_SIZE, x_size, (int)(y_size * scale) };
		originrect = { 0, 0, texture->Width(), (int)(texture->Height() * scale) };
	}
}