#include "explosion_entity.h"

namespace bejeweled
{
	void ExplosionEntity::OnStart(SDL_Renderer* g_renderer)
	{
		texture = TextureManager::GetInstance().CreateTexture(g_renderer, "sprite_sheet", "sprite_sheet");
		fillrect = { x_pos_index * TILE_PIXEL_SIZE, y_pos_index * TILE_PIXEL_SIZE, x_size, y_size };
		originrect = { TILE_PIXEL_SIZE * piece_id, 0, x_size, y_size };
	}

	void ExplosionEntity::OnRender(SDL_Renderer* g_renderer, int last_frame_duration)
	{
		float percentageComplete = (float)time_moving / animation_time;

		// We lerp our scale towards 0
		float new_scale = math::Lerp(1.0f, 0.0f, math::CubicEaseInOut(percentageComplete));

		if (percentageComplete >= 1.0f)
		{
			finished = true;
			time_moving = 0;
		}
		else
		{
			int new_x_size = (int)(x_size * new_scale);
			int new_y_size = (int)(y_size * new_scale);

			fillrect = { x_pos_index * TILE_PIXEL_SIZE + HALF_TILE_PIXEL_SIZE - (int)(new_x_size * 0.5f),
							y_pos_index * TILE_PIXEL_SIZE + HALF_TILE_PIXEL_SIZE + (int)(new_y_size * 0.5f),
							new_x_size, new_y_size };

			time_moving += last_frame_duration;
			Render(g_renderer, texture->SDLTexture(), fillrect, originrect, 0);
		}
	}

	bool ExplosionEntity::Finished() const
	{
		return finished;
	}
}