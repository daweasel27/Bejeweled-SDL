#pragma once

#include <vector>
#include <memory>
#include "tile_entity.h"

namespace bejeweled
{
	/*
		Class containing a collection of tiles and their respective pieces.
	*/
	class MapEntity : Renderable
	{
		std::vector<std::shared_ptr<TileEntity>> tiles;

	public:
		MapEntity();
		~MapEntity();

		// Initializes the tiles and then the pieces contained in them.
		void OnStart(SDL_Renderer* g_renderer);

		// Renders tiles and then the pieces contained in them.
		void OnRender(SDL_Renderer* g_renderer, int last_frame_duration);

		// Helper functions to obtain tiles.
		std::shared_ptr<TileEntity> TileFromIndex(int index);
		std::shared_ptr<TileEntity> TileFromXY(int x, int y);

		std::shared_ptr<TileEntity> Right(std::shared_ptr<TileEntity> current_tile);
		std::shared_ptr<TileEntity> Left(std::shared_ptr<TileEntity> current_tile);
		std::shared_ptr<TileEntity> Up(std::shared_ptr<TileEntity> current_tile);
		std::shared_ptr<TileEntity> Down(std::shared_ptr<TileEntity> current_tile);
	};
}