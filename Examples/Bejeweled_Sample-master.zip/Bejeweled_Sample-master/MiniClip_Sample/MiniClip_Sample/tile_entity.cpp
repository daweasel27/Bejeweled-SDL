#include "tile_entity.h"

namespace bejeweled
{
	void TileEntity::OnStart(SDL_Renderer* g_renderer)
	{
		texture = TextureManager::GetInstance().CreateTexture(g_renderer, "sprite_sheet", "sprite_sheet");
		fillrect = { x_pos_index * TILE_PIXEL_SIZE, y_pos_index * TILE_PIXEL_SIZE, x_size, y_size };
		originrect = { 0, 0, x_size, y_size };
	}

	void TileEntity::OnRender(SDL_Renderer* g_renderer, int last_frame_duration)
	{
		//Render background tile texture
		Render(g_renderer, texture->SDLTexture(), fillrect, originrect, TILE_PIXEL_SIZE);
	}

	void TileEntity::FillWithPiece(std::shared_ptr<bejeweled::PieceEntity> new_piece)
	{
		assert(new_piece != nullptr);
		piece = new_piece;
	}

	void TileEntity::DestroyPiece()
	{
		assert(piece != nullptr);
		piece.reset();
		piece = nullptr;
	}

	bool TileEntity::HasPiece() const
	{
		return piece != nullptr;
	}

	bool TileEntity::IsAdjacent(std::shared_ptr<TileEntity> other_tile) const
	{
		// Not equal
		bool equal_x = X() == other_tile->X();
		bool equal_y = Y() == other_tile->Y();
		// Is adjacent to the left or to the right
		bool adjacent_left_right = X() == other_tile->X() + 1 || X() == other_tile->X() - 1;
		// Is adjacent upwards or downwards
		bool adjacent_up_down = Y() == other_tile->Y() + 1 || Y() == other_tile->Y() - 1;

		return (!equal_x || !equal_y) && ((adjacent_left_right && !adjacent_up_down && equal_y) || (adjacent_up_down && !adjacent_left_right && equal_x));
	}

	std::shared_ptr<PieceEntity> TileEntity::Piece() const
	{
		assert(piece != nullptr);
		return piece;
	}

	int TileEntity::X() const
	{
		return x_pos_index;
	}

	int TileEntity::Y() const
	{
		return y_pos_index;
	}
}