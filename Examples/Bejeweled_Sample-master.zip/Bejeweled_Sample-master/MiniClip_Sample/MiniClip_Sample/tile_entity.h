#pragma once

#include "piece_entity.h"
#include "extensions.h"

namespace bejeweled
{
	/*
		Class representing a tile/position on the world map.
		Contains a piece.
	*/
	class TileEntity : public QuadEntity
	{
		std::shared_ptr<PieceEntity> piece;

	public:
		TileEntity(int x, int y, int size) : QuadEntity(x, y, size, size) {}
		~TileEntity() {}

		void OnStart(SDL_Renderer* g_renderer);
		void OnRender(SDL_Renderer* g_renderer, int last_frame_duration);

		void FillWithPiece(std::shared_ptr<PieceEntity> new_piece);

		void DestroyPiece();

		bool HasPiece() const;

		// Returns true if another tile is Up, down, left or right of the current tile.
		bool IsAdjacent(std::shared_ptr<TileEntity> other_tile) const;
		std::shared_ptr<PieceEntity> Piece() const;

		int X() const;
		int Y() const;
	};
}