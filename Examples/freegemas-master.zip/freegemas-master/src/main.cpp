#include "Game.h"

int main(int argc, char *argv[])
{
    (void) argc;
    (void) argv;

    Game w;
    w.show();

    return 0;
}
