#ifndef UTIL_H
#define UTIL_H

float getRandomFloat(float a, float b);
int getRandomInt (int min, int max) ;

#endif