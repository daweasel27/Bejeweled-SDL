#pragma once

#include "Scene.h"
#include "Image.h"
#include "Sound.h"
#include "Button.h"

#include "GameStats.h"
#include "GameGrid.h"
#include "GameOverMenu.h"

#define BLOCK_VALUE 15

class Engine;

class GameScene : public Scene {

public:
	/**
	@brief Create a new GameScene
	@param engine The engine to draw to
	*/
	GameScene(Engine* engine);

	/**
	@brief Destroys the GameScene
	*/
	~GameScene();

	/**
	@brief Controls the game logic and interactions
	*/
	void update();

	/**
	@brief Draws the game
	*/
	void draw();

	/**
	@brief Handles the mouse input
	@param button The button code
	*/
	void mouseButtonDown(Uint8 button);

private:
	///Images
	SDL::Image backgroundImg;

	///Buttons
	std::shared_ptr<Button> pushButton;

	///Sounds
	SDL::Sound backgroundMusic;

	///Scene components
	std::shared_ptr<GameGrid> game;
	std::shared_ptr<GameStats> stats;
	std::shared_ptr<GameOverMenu> gOverMenu;

	///Stats
	int level;
	int score;

	///Push handling
	int lastTicks;
	int pushInterval;

	///Game over state
	bool gameOver;

	/**
	@brief Calculates the push interval for the level
	*/
	int calculatePushInterval();

	/**
	@brief Updates the score with the number of blocks destroyed
	@param blocksDestroyed The nuber of blocks destroyed in the last move
	*/
	void updateScore(int blocksDestroyed);

	/**
	@brief Checks if the score makes the level increment
	*/
	void checkLevelUp();

	/**
	@brief Outputs the level refering to the score
	*/
	int scoreToLevel();

	/**
	@brief Calculates the needed score to level up given a level
	@param lvl The level to calculate the score
	*/
	int scoreToLevelUp(int lvl);

	/**
	@brief Resets the game
	*/
	void resetGame();

	/**
	@brief Converts the mouse position on the window into a position
			of the game grid 
	@param x The x coordinate
	@param y The y coordinate
	*/
	SDL_Point convertMousePosIntoGridPos(int x, int y);
};