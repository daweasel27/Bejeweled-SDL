#include "Text.h"

#include <iostream>

SDL::Text::Text()
{
	if (!TTF_WasInit()) {
		printf("merda");
	}
}

SDL::Text::~Text()
{
	TTF_CloseFont(font);
	font = nullptr;
}

void SDL::Text::setParams(Window* wind, std::string path, int fontSize)
{
	window = wind;
	filePath = path;
	size = fontSize;

	font = TTF_OpenFont(filePath.c_str(), size);
	if (font == NULL) {
		cerr << TTF_GetError();
	}
}

SDL::Image SDL::Text::renderText(std::string text, SDL_Color color)
{
	SDL_Surface* surf = TTF_RenderUTF8_Blended(font, text.c_str(), color);
	return toImage(surf);
}

SDL::Image SDL::Text::toImage(SDL_Surface * surf)
{
	SDL_Texture* text = SDL_CreateTextureFromSurface(window->getRenderer(), surf);

	SDL_FreeSurface(surf);

	SDL::Image resultImg;
	resultImg.setWindow(window);
	resultImg.setTexture(text);

	return resultImg;
}
