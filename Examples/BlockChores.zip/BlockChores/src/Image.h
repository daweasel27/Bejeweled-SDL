#pragma once

#include <SDL.h>
#include <SDL_image.h>

#include <string>
#include <memory>
using namespace std;

namespace SDL {
	class Window;

	class Image {

	public:
		/**
		@brief The contructor for the Image class
		*/
		Image();

		/**
		@brief Destructor for the Image class
		*/
		~Image();

		/**
		@brief Sets the image containing window
		@param window The window
		*/
		void setWindow(Window* window);

		/**
		@brief Sets the file path
		@param filePath The file to the path
		*/
		void setPath(string filePath);

		/**
		@brief returns the width of the Image
		*/
		int getWidth();

		/**
		@brief returns the height of the Image
		*/
		int getHeight();

		/**
		@brief returns the Image's X position
		*/
		int getXPos();

		/**
		@brief returns the Image's X position
		*/
		int getYPos();

		/**
		@brief Draws the image on the window
		*/
		bool draw(int x, int y, int z, double factorX = 1, double factorY = 1);

		/**
		@brief Sets the texture of the Image
		@tex The texture
		*/
		void setTexture(SDL_Texture* tex);

	private:
		/**
		@brief The Window that contains the Image
		*/
		Window* containingWindow = NULL;

		/**
		@brief The width of the Image
		*/
		int width;

		/**
		@brief The height of the Image
		*/
		int height;

		/**
		@brief The position of the Image
		*/
		int posX; 
		int posY;

		/**
		@brief the file path of the Image
		*/
		string path;

		/**
		@brief The texture of the Image
		We're holding it in a shared pointer so it's easier to copy into other Images
		*/
		shared_ptr<SDL_Texture> texture;

		/**
		@brief The destroyer for the texture, called when there's no more entities pointing
		to the texture
		*/
		struct DestroyTexture
		{
			void operator()(SDL_Texture * texture) const
			{
				if (texture)
				{
					SDL_DestroyTexture(texture);
				}
			}
		};

		/**
		@brief Verifies if both window and path are set
		Window and Path are needed to load the texture
		*/
		bool verifyParameters();

		/**
		@brief loads the Image texture
		*/
		bool loadTexture();
	};
}