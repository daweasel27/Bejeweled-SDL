#include "Scene.h"

Scene::Scene(Engine * engine) : engine(engine)
{
}

Scene::~Scene()
{
}
