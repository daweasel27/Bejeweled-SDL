#include "GameScene.h"
#include "Engine.h"

#include <iostream>

GameScene::GameScene(Engine * engine): Scene(engine)
{
	//Init background
	backgroundImg.setWindow(engine);
	backgroundImg.setPath("Assets/Images/gameBackground.png");

	//Init push button
	pushButton = std::make_shared<Button>(engine, "Assets/Images/pushButton.png");
	pushButton->setPosition(720, 530);

	//Init background music
	backgroundMusic.setPath("Assets/Sounds/background.mp3");
	backgroundMusic.play(0.4,true);

	game = std::make_shared<GameGrid>(engine);

	stats = std::make_shared<GameStats>(engine);

	level = 1;
	score = 0;
	lastTicks = SDL_GetTicks();
	pushInterval = calculatePushInterval();
	gameOver = false;
}

GameScene::~GameScene()
{
}

void GameScene::update()
{
	game->update();

	//The only thing we let update in a game over state is the game grid
	//so any pending animation can finish
	if (gameOver) {
		return;
	}

	GameState gState = game->getState();

	//Only count the next push after the level up sequence is done
	if (gState == LEVEL_UP || gState == GENERATE_GRID) {
		lastTicks = SDL_GetTicks();
		return;
	}

	if (gState != GAME_OVER) {
		//Handles the push logic
		int actualTicks = SDL_GetTicks();
		if (actualTicks - lastTicks >= pushInterval) {
			lastTicks = actualTicks;
			game->push();
		}
		stats->updatePushBar(pushInterval, actualTicks - lastTicks);
	}
	else {
		//Creates the game over menu
		gameOver = true;
		gOverMenu = std::make_shared<GameOverMenu>(engine, level, score);
	}
}

void GameScene::draw()
{
	//Draw the background
	backgroundImg.draw(0, 0, 1);

	//Draw the push button
	pushButton->draw();

	game->draw();
	stats->draw();

	if (gameOver) {
		gOverMenu->draw();
	}
}

void GameScene::mouseButtonDown(Uint8 button)
{
	GameState gstate = game->getState();

	//We only handle input when the game is Idle or
	//in the Game Over Menu
	if (gstate != IDLE && gstate != GAME_OVER) {
		return;
	}

	if (button == SDL_BUTTON_LEFT)
	{

		// Get mouse position
		int y = engine->getMouseY();
		int x = engine->getMouseX();

		if (gameOver && gOverMenu->playAgainPressed(x, y)) {
			resetGame();
			return;
		}

		//Check if the press was on the push button
		if (pushButton->isInside(x,y)) {
			game->push();
			lastTicks = SDL_GetTicks();
			return;
		}

		//Convert the mouse coordinates into the board coordinates
		SDL_Point arrayPos = convertMousePosIntoGridPos(x, y);

		//Check if the press was on the game board
		if (arrayPos.x >= 0 && arrayPos.x < BOARD_WIDTH && arrayPos.y >= 0 && arrayPos.y < BOARD_HEIGHT) {
			int blocksDestroyed = game->handleBlockClick(arrayPos.x, arrayPos.y);

			if (blocksDestroyed != 0) {
				updateScore(blocksDestroyed);
			}
		}

	}
}

SDL_Point GameScene::convertMousePosIntoGridPos(int x, int y) {
	SDL_Point result = { 0,0 };
	int resultX = (x - GAME_DRAW_OFFSET_X) / BLOCK_DRAW_SIZE;	
	int resultY = (y - GAME_DRAW_OFFSET_Y) / BLOCK_DRAW_SIZE;
	result = { resultX, resultY };

	return result;
}

int GameScene::calculatePushInterval()
{
	return 9000 - 100 * (level - 1);
}

void GameScene::updateScore(int blocksDestroyed)
{
	score += blocksDestroyed * BLOCK_VALUE * level;
	checkLevelUp();

	//Update the stats on screen
	stats->updateScore(score);
	stats->updateLevelBar(score, scoreToLevelUp(level - 1), scoreToLevelUp(level));
}

void GameScene::checkLevelUp()
{
	if (scoreToLevel() > level) {
		level++;
		//Calculate the new push interval and reset the push counter
		calculatePushInterval();
		lastTicks = SDL_GetTicks();

		game->levelUp();
		stats->updateLevel(level);
	}
}

int GameScene::scoreToLevel()
{
	//Calculate actual score needed to level up
	int toLevelUp = scoreToLevelUp(level);

	if (toLevelUp <= score) {
		return level + 1;
	}

	return level;
}

int GameScene::scoreToLevelUp(int lvl)
{
	switch (lvl)
	{
	case 0:
		return 0;
		break;
	case 1:
		return 600;
		break;
	default:
		return ((lvl + 1) * BLOCK_VALUE) * (lvl - 1) * 100;
		break;
	}
}

void GameScene::resetGame()
{
	//Set the initial score and level values
	level = 1;
	score = 0;
	
	//Calculate the new push interval and reset the push counter
	lastTicks = SDL_GetTicks();
	pushInterval = calculatePushInterval();

	gameOver = false;
	//Reset the game
	game->reset();

	//Update the stats
	stats->updateLevel(level);
	stats->updateScore(score);
}


