#pragma once

#include <string>

#include <SDL_ttf.h>

#include "Window.h"
#include "Image.h"

namespace SDL {
	class Text
	{
	public:
		/**
		@brief The constructor for Text
		*/
		Text();
		~Text();

		/**
		@brief Sets the parameters for the text
		@param win The window to render the text
		@param path The path to the font file
		@param fontSize The size of the text
		*/
		void setParams(Window* win, std::string path, int fontSize);

		/**
		@brief Renders the given text onto an Image
		@param text The text to render
		@param color The color of the text
		*/
		SDL::Image renderText(std::string text, SDL_Color color);

	private:
		///The window to render to
		Window* window;

		///The path to the file
		std::string filePath;

		///The size of the font
		int size;

		///The loaded font
		TTF_Font* font = NULL;

		/**
		@brief Converts a surface to an image
		@param surf The surface to be converted
		*/
		SDL::Image toImage(SDL_Surface* surf);
	};
}
