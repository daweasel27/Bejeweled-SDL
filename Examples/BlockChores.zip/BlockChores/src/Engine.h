#pragma once

#include <string>
#include <memory>

#include "Window.h"

enum SceneID {
	MAINMENU,
	GAME
};

class Scene;

class Engine : public SDL::Window
{
public:
	/**
	@brief Creates a new Engine
	*/
	Engine();
	~Engine();

	/**
	@brief Ran at every frame. Handles the logic
	@description It calls the update function of the active Scene
	*/
	void update();

	/**
	@brief Ran at every frame. Handles the draw
	@description It calls the draw function of the active Scene
	*/
	void draw();

	/**
	@brief Handles the mouse button down event
	@description It calls the mouse button down event handling function of the active Scene
	*/
	void mouseButtonDown(Uint8 button);

	/**
	@brief Switches the active scene
	*/
	void switchScene(SceneID sceneID);

private:

	///The current Scene data
	std::shared_ptr<Scene> currentScene = nullptr;
	SceneID currentSceneID;
};
