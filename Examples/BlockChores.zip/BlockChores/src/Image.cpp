#include "Image.h"
#include "Window.h"

SDL::Image::Image(): containingWindow(NULL), width(0), height(0)
{
}

SDL::Image::~Image()
{
	containingWindow = NULL;
}

void SDL::Image::setWindow(Window * window)
{
	containingWindow = window;
}

void SDL::Image::setPath(string filePath)
{
	path = filePath;
	loadTexture();
}

void SDL::Image::setTexture(SDL_Texture * tex)
{
	//In practice, what reset does is call the destructor of the texture,
	//ensuring memory is well managed, and then copies the new value
	texture.reset(tex, DestroyTexture());

	//This function will get the texture's dimensions
	SDL_QueryTexture(texture.get(), NULL, NULL, &width, &height);
}

int SDL::Image::getWidth()
{
	return width;
}

int SDL::Image::getHeight()
{
	return height;
}

int SDL::Image::getXPos()
{
	return posX;
}

int SDL::Image::getYPos()
{
	return posY;
}

bool SDL::Image::draw(int x, int y, int z, double factorX, double factorY)
{
	SDL_Rect destRect;
	destRect.w = width * factorX;
	destRect.h = height * factorY;
	destRect.x = x;
	destRect.y = y;

	int success = SDL_RenderCopyEx(containingWindow->getRenderer(), texture.get(), NULL, &destRect, 0, NULL, SDL_FLIP_NONE);

	if (success == 0) {
		posX = x;
		posY = y;
		return true;
	}
	else {
		return false;
	}
}

bool SDL::Image::verifyParameters()
{
	if (containingWindow == nullptr & path != "") {
		return true;
	}
	else {
		return false;
	}
}

bool SDL::Image::loadTexture()
{
	//load texture from the file path
	SDL_Texture* tex = IMG_LoadTexture(containingWindow->getRenderer(), path.c_str());

	if (tex == nullptr) {
		return false;
	}

	setTexture(tex);

	return true;
}
