#include "Sound.h"

SDL::Sound::Sound()
{
}

SDL::Sound::~Sound()
{
	Mix_FreeChunk(sound);
}

void SDL::Sound::setPath(std::string filePath)
{
	sound = Mix_LoadWAV(filePath.c_str());
}

void SDL::Sound::play(float volume, bool repeat)
{
	Mix_VolumeChunk(sound, 128 * volume);
	Mix_FadeInChannel(-1, sound, repeat ? -1 : 0, 0);
}

void SDL::Sound::stop()
{
	//Mix_FadeOutChannel(200);
}
