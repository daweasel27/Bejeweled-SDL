#pragma once

#include "Image.h"

class Engine;

class Button
{
public:
	/**
	@brief The constructor for the Button
	@param e The engine to draw to
	@param imgFilePath The file path for the button image
	*/
	Button(Engine* e, std::string imgFilePath);
	~Button();

	/**
	@brief Draws the button
	*/
	void draw();

	/**
	@brief Checks if the given coordinates are inside the button
	@param x The x coordinate
	@param y The y coordinate
	*/
	bool isInside(int x, int y);

	/**
	@brief Centers the Button horizontally on the screen
	@param windowWidth The size of the window
	*/
	void centerHorizontally(int windowWidth);

	/**
	@brief Sets the button position on the given coordinates
	@param x The x coordinate
	@param y The y coordinate
	*/
	void setPosition(int x, int y);

	/**
	@brief Gets the button Height
	*/
	int getHeight();

	/**
	@brief Gets the button width
	*/
	int getWidth();

private:
	///Image
	SDL::Image img;

	Engine* engine;

	///Button's position
	int posX;
	int posY;

};
