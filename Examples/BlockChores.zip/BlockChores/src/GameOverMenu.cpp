#include "GameOverMenu.h"
#include "Engine.h"

GameOverMenu::GameOverMenu(Engine* e, int lvl, int scr): engine(e)
{
	//Init background
	backgroundImg.setWindow(engine);
	backgroundImg.setPath("Assets/Images/gameOverMenu.png");

	//Init background
	//playAgainButton = new Button(engine, "Assets/Images/playAgainButton.png");
	playAgainButton = std::make_shared<Button>(engine, "Assets/Images/playAgainButton.png");
	playAgainButton->setPosition(0, 394);
	playAgainButton->centerHorizontally(engine->getWidth());

	fontUI.setParams(engine, "Assets/Fonts/smallfont.ttf", 36);

	scoreImg = fontUI.renderText(std::to_string(scr), { 0, 0, 0, 255 });

	levelImg = fontUI.renderText(std::to_string(lvl), { 0, 0, 0, 255 });
}

GameOverMenu::~GameOverMenu()
{
}

void GameOverMenu::draw()
{
	backgroundImg.draw(centerImgHorizontally(backgroundImg), 145, 1);
	playAgainButton->draw();
	scoreImg.draw(centerImgHorizontally(scoreImg), 340, 1);
	levelImg.draw(centerImgHorizontally(levelImg), 265, 1);
}

bool GameOverMenu::playAgainPressed(int mouseX, int mouseY)
{
	return playAgainButton->isInside(mouseX, mouseY);
}

int GameOverMenu::centerImgHorizontally(SDL::Image img)
{
	return engine->getWidth() / 2 - img.getWidth() / 2;
}
