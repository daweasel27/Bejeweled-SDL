#include "GameGrid.h"
#include "Engine.h"

#include <ctime>

GameGrid::GameGrid(Engine* e): engine(e)
{
	std::srand((unsigned)time(NULL));

	loadResources();
	generateGrid();

	updating = false;

	currentState = IDLE;
}

GameGrid::~GameGrid()
{
}

void GameGrid::loadResources()
{
	//Init background
	blockRedImg.setWindow(engine);
	blockRedImg.setPath("Assets/Images/Block-red.png");

	//Init background
	blockGreenImg.setWindow(engine);
	blockGreenImg.setPath("Assets/Images/Block-green.png");

	//Init background
	blockBlueImg.setWindow(engine);
	blockBlueImg.setPath("Assets/Images/Block-blue.png");

	//Init background
	blockGreyImg.setWindow(engine);
	blockGreyImg.setPath("Assets/Images/Block-grey.png");

	//Init background
	blockOrangeImg.setWindow(engine);
	blockOrangeImg.setPath("Assets/Images/Block-orange.png");

	//Init game over sound
	gameOverSound.setPath("Assets/Sounds/gameOver.wav");

	//Init level up sound
	levelUpSound.setPath("Assets/Sounds/levelUp.wav");

	//Init destroy blocks sound
	destroyBlocksSound.setPath("Assets/Sounds/destroyBlocks.wav");

	//Init push sound
	pushSound.setPath("Assets/Sounds/push.wav");

	//Init generate board sound
	generateBoardSound.setPath("Assets/Sounds/generateBoard.wav");

}

void GameGrid::update()
{
	for (int i = 0; i < BOARD_WIDTH; ++i)
	{
		for (int j = 0; j < BOARD_HEIGHT; ++j)
		{
			if (!blocks[i + j * BOARD_WIDTH].isEmpty()) {
				blocks[i + j * BOARD_WIDTH].update();
			}
		}
	}

	if (!isUpdating() && stateQueue.size() != 0) {
		handleState();
	}
}

void GameGrid::draw()
{
	for (int i = 0; i < BOARD_WIDTH; ++i)
	{
		for (int j = 0; j < BOARD_HEIGHT; ++j)
		{
			blocks[i + j * BOARD_WIDTH].draw(GAME_DRAW_OFFSET_X, GAME_DRAW_OFFSET_Y);
		}
	}
}

void GameGrid::gameOver()
{
	for (int y = 0; y < BOARD_HEIGHT; y++) {
		if (!blocks[0 + y * BOARD_WIDTH].isEmpty()) {
			blocks[0 + y * BOARD_WIDTH].setUpdatePositions(BOARD_HEIGHT + 2);
			blocks[0 + y * BOARD_WIDTH].drop(BOARD_HEIGHT * 3);
		}
	}

	gameOverSound.play();
}

void GameGrid::handleState()
{
	if (currentState == GAME_OVER) {
		return;
	}

	currentState = stateQueue.front();

	stateQueue.pop();

	switch (currentState)
	{
	case IDLE:
		break;
	case DESTROY_BLOCKS:
		destroyBlocks();
		break;
	case DROP_BLOCKS:
		dropBlocks();
		break;
	case COMPACT_BLOCKS:
		compactBlocks();
		break;
	case PUSH_BLOCKS:
		pushGrid();
		break;
	case LEVEL_UP:
		levelUpGrid();
		break;
	case GENERATE_GRID:
		generateGrid();
		break;
	case GAME_OVER:
		gameOver();
		break;
	default:
		break;
	}

	if (stateQueue.size() == 0 && currentState != GAME_OVER) {
		currentState = IDLE;
	}
}
//Generate Grid
void GameGrid::generateGrid()
{
	cleanGrid();

	for (int i = BOARD_WIDTH - INITIAL_BOARD_WIDTH; i < BOARD_WIDTH; ++i)
	{
		for (int j = BOARD_HEIGHT - INITIAL_BOARD_HEIGHT; j < BOARD_HEIGHT; ++j)
		{
			blocks[i + j * BOARD_WIDTH].setType(rand() % 5);
			blocks[i + j * BOARD_WIDTH].setPosition((float)i + INITIAL_BOARD_WIDTH, (float)j);
			blocks[i + j * BOARD_WIDTH].setImg(getImgByType(blocks[i + j * BOARD_WIDTH].getType()));
			blocks[i + j * BOARD_WIDTH].shiftLeft(i + INITIAL_BOARD_WIDTH, j, INITIAL_BOARD_WIDTH, BOARD_WIDTH);
			blocks[i + j * BOARD_WIDTH].setEmpty(false);
			blocks[i + j * BOARD_WIDTH].setToDestroy(false);

		}
	}

	generateBoardSound.play();
}

void GameGrid::cleanGrid()
{
	for (int i = 0; i < BOARD_WIDTH; ++i)
	{
		for (int j = 0; j < BOARD_HEIGHT; ++j)
		{
			//blocks[i + j * BOARD_WIDTH].~Block();
			blocks[i + j * BOARD_WIDTH].setEmpty(true);
		}
	}
}

//Destroy blocks
int GameGrid::checkSameTypeAdjacents(int x, int y)
{
	int result = 0;

	if (!blocks[x + y * BOARD_WIDTH].isEmpty()) {
		//Check top block
		if (y != 0 && !blocks[x + (y - 1) * BOARD_WIDTH].isEmpty()) {
			if (blocks[x + (y - 1) * BOARD_WIDTH].getType() == blocks[x + y * BOARD_WIDTH].getType()) {

				if (!blocks[x + y * BOARD_WIDTH].toDestroy()) {
					blocks[x + y * BOARD_WIDTH].setToDestroy(true);
					result++;
				}

				if (!blocks[x + (y - 1) * BOARD_WIDTH].toDestroy()) {
					result += checkSameTypeAdjacents(x, y - 1);
				}
			}
		}

		//Check bottom block
		if (y != BOARD_HEIGHT - 1 && !blocks[x + (y + 1) * BOARD_WIDTH].isEmpty()) {
			if (blocks[x + (y + 1) * BOARD_WIDTH].getType() == blocks[x + y * BOARD_WIDTH].getType()) {

				if (!blocks[x + y * BOARD_WIDTH].toDestroy()) {
					blocks[x + y * BOARD_WIDTH].setToDestroy(true);
					result++;
				}

				if (!blocks[x + (y + 1) * BOARD_WIDTH].toDestroy()) {
					result += checkSameTypeAdjacents(x, y + 1);
				}
			}
		}

		//Check left block
		if (x != 0 && !blocks[(x - 1) + y * BOARD_WIDTH].isEmpty()) {
			if (blocks[(x - 1) + y * BOARD_WIDTH].getType() == blocks[x + y * BOARD_WIDTH].getType()) {

				if (!blocks[x + y * BOARD_WIDTH].toDestroy()) {
					blocks[x + y * BOARD_WIDTH].setToDestroy(true);
					result++;
				}

				if (!blocks[(x - 1) + y * BOARD_WIDTH].toDestroy()) {
					result += checkSameTypeAdjacents(x - 1, y);
				}
			}
		}

		//Check right block
		if (x != BOARD_WIDTH - 1 && !blocks[(x + 1) + y * BOARD_WIDTH].isEmpty()) {
			if (blocks[(x + 1) + y * BOARD_WIDTH].getType() == blocks[x + y * BOARD_WIDTH].getType()) {

				if (!blocks[x + y * BOARD_WIDTH].toDestroy()) {
					blocks[x + y * BOARD_WIDTH].setToDestroy(true);
					result++;
				}

				if (!blocks[(x + 1) + y * BOARD_WIDTH].toDestroy()) {
					result += checkSameTypeAdjacents(x + 1, y);
				}
			}
		}
	}

	return result;
}

int GameGrid::destroyBlocks()
{
	int blocksDestroyed = 0;

	for (int i = 0; i < BOARD_WIDTH; i++) {
		for (int j = 0; j < BOARD_HEIGHT; j++) {
			if (!blocks[i + j * BOARD_WIDTH].isEmpty() && blocks[i + j * BOARD_WIDTH].toDestroy()) {
				blocks[i + j * BOARD_WIDTH].setEmpty(true);
				blocksDestroyed++;
			}
		}
	}

	destroyBlocksSound.play();

	return blocksDestroyed;
}

//Level Up
void GameGrid::levelUp()
{
	stateQueue.push(LEVEL_UP);
	stateQueue.push(GENERATE_GRID);
}

void GameGrid::levelUpGrid()
{
	for (int i = 0; i < BOARD_WIDTH; ++i)
	{
		for (int j = 0; j < BOARD_HEIGHT; ++j)
		{
			if (!blocks[i + j * BOARD_WIDTH].isEmpty()) {
				blocks[i + j * BOARD_WIDTH].setUpdatePositions(BOARD_HEIGHT + 2);
				//blocks[i + j * BOARD_WIDTH].setPosition(i, j + BOARD_HEIGHT + 2);
				blocks[i + j * BOARD_WIDTH].drop(BOARD_HEIGHT * 3);
			}
		}
	}

	levelUpSound.play();
}

//Push
void GameGrid::push() {
	stateQueue.push(PUSH_BLOCKS);
}

void GameGrid::pushGrid()
{
	//We don't want to push outside of the grid space
	if (!checkEmptyColumn(0)) {
		return;
	}

	pushSound.play();

	for (int x = 0; x < BOARD_WIDTH; x++) {
		if (!checkEmptyColumn(x)) {
			for (int k = x; k < BOARD_WIDTH; k++) {
				moveColumn(k - 1, k, "left");
			}
			generateNewColumn();

			if (!checkEmptyColumn(0)) {
				stateQueue.empty();
				stateQueue.push(GAME_OVER);
			}

			return;
		}
	}
}

//Compact
void GameGrid::compactBlocks()
{
	for (int x = BOARD_WIDTH - 1; x >= 0; x--) {

		bool keepSearching = false;

		if (checkEmptyColumn(x)) {
			for (int k = x - 1; k >= 0; k--) {
				if (!checkEmptyColumn(k)) {
					moveColumn(x, k, "right");
					keepSearching = true;
					break;
				}
			}

			if (!keepSearching) return;

		}
	}

}

//Drop blocks
void GameGrid::dropBlocks()
{
	for (int i = 0; i < BOARD_WIDTH; i++) {
		bool dropsExist = false;
		for (int j = BOARD_HEIGHT - 1; j >= 0; j--) {

			if (blocks[i + j * BOARD_WIDTH].isEmpty()) {

				for (int k = j - 1; k >= 0; k--) {
					//Calculate drops
					if (!blocks[i + k * BOARD_WIDTH].isEmpty()) {
						blocks[i + k * BOARD_WIDTH].incrementUpdatePositions();
						dropsExist = true;
					}
				}

			}
		}

		//Do the drop
		if (dropsExist) dropBlocksOfColumn(i);
	}
}

void GameGrid::dropBlocksOfColumn(int x)
{
	for (int y = BOARD_HEIGHT - 1; y >= 0; y--) {
		if (!blocks[x + y * BOARD_WIDTH].isEmpty()) {

			int drop = blocks[x + y * BOARD_WIDTH].getUpdatePositions();
			if (drop != 0) {
				blocks[x + (y + drop) * BOARD_WIDTH] = blocks[x + y * BOARD_WIDTH];

				//initialize animation parameters
				blocks[x + (y + drop) * BOARD_WIDTH].drop(BOARD_HEIGHT);
				blocks[x + y * BOARD_WIDTH].setEmpty(true);
			}

		}
	}
}

bool GameGrid::checkEmptyColumn(int x)
{
	bool result = true;

	for (int y = BOARD_HEIGHT - 1; y >= 0; y--) {
		if (!blocks[x + y * BOARD_WIDTH].isEmpty()) {
			result = false;
			return result;
		}
	}

	return result;
}

void GameGrid::moveColumn(int destIndex, int origIndex, string side)
{
	for (int y = BOARD_HEIGHT - 1; y >= 0; y--) {
		blocks[destIndex + y * BOARD_WIDTH] = blocks[origIndex + y * BOARD_WIDTH];

		if (!blocks[destIndex + y * BOARD_WIDTH].isEmpty())
		{
			//blocks[firstIndex + y * BOARD_WIDTH].setPosition(firstIndex, y);

			if (side == "left") {
				blocks[destIndex + y * BOARD_WIDTH].shiftLeft(destIndex + 1, y, 1, BOARD_WIDTH);
			}

			if (side == "right") {
				blocks[destIndex + y * BOARD_WIDTH].shiftRight(origIndex, y, destIndex - origIndex, BOARD_WIDTH);
			}

		}
		//blocks[secondIndex + y * BOARD_WIDTH].~Block();
		blocks[origIndex + y * BOARD_WIDTH].setEmpty(true);
	}
}

void GameGrid::generateNewColumn()
{
	for (int y = BOARD_HEIGHT - 1; y >= 0; y--) {
		blocks[(BOARD_WIDTH - 1) + y * BOARD_WIDTH].setType(rand() % 5);
		blocks[(BOARD_WIDTH - 1) + y * BOARD_WIDTH].setPosition((float)BOARD_WIDTH, (float)y);
		blocks[(BOARD_WIDTH - 1) + y * BOARD_WIDTH].setImg(getImgByType(blocks[(BOARD_WIDTH - 1) + y * BOARD_WIDTH].getType()));
		blocks[(BOARD_WIDTH - 1) + y * BOARD_WIDTH].shiftLeft(BOARD_WIDTH, y, 1, BOARD_WIDTH);
		blocks[(BOARD_WIDTH - 1) + y * BOARD_WIDTH].setEmpty(false);
		blocks[(BOARD_WIDTH - 1) + y * BOARD_WIDTH].setToDestroy(false);
	}
}

void GameGrid::reset()
{
	stateQueue.empty();
	currentState = IDLE;
	generateGrid();
}

int GameGrid::handleBlockClick(int x, int y)
{
	int blocksDestroyed = checkSameTypeAdjacents(x, y);

	if (blocksDestroyed > 0) {
		// wait for animation conclusion
		stateQueue.push(DESTROY_BLOCKS);
		stateQueue.push(DROP_BLOCKS);
		stateQueue.push(COMPACT_BLOCKS);
	}

	return blocksDestroyed;
}

SDL::Image GameGrid::getImgByType(int type)
{
	switch (type)
	{
	case BLOCK_RED:
		return blockRedImg;
	case BLOCK_GREEN:
		return blockGreenImg;
	case BLOCK_BLUE:
		return blockBlueImg;
	case BLOCK_GREY:
		return blockGreyImg;
	case BLOCK_ORANGE:
		return blockOrangeImg;
	default:
		break;
	}

	return blockRedImg;
}

bool GameGrid::isUpdating() {
	bool result = false;

	//Checks if there's any block updating
	for (int i = 0; i < BOARD_WIDTH; ++i)
	{
		for (int j = 0; j < BOARD_HEIGHT; ++j)
		{
			if (!blocks[i + j * BOARD_WIDTH].isEmpty() && blocks[i + j * BOARD_WIDTH].toUpdate()) {
				result = true;
				break;
				break;
			}
		}
	}

	return result;
}

GameState GameGrid::getState()
{
	return currentState;
}
