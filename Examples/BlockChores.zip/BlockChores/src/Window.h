#pragma once

#include <SDL.h>
#include <SDL_image.h>
#include <SDL_ttf.h>
#include <SDL_mixer.h>

#include <string>

namespace SDL {

	class Window {

	public:
		/**
		@brief Creates a new SDL window with given parameters
		@param width The Window width
		@param height The Window height
		@param title The Window title
		*/
		Window(unsigned width, unsigned height, std::string title);

		/**
		@brief Destroys the Window
		*/
		~Window();

		/**
		@brief Shows the Window and starts the game
		*/
		void show();


		/**
		@brief Closes the Window and stops the game
		*/
		void close();


		/**
		@brief Handles the game logic at every frame. Has to be overloaded
		*/
		virtual void update() = 0;

		/**
		@brief Handles the graphic drawing at every frame. Has to be overloaded
		*/
		virtual void draw() = 0;

		/**
		@brief Event for the mouse button down
		*/
		virtual void mouseButtonDown(Uint8) { }

		/**
		@brief Returns the horizontal position of the mouse
		*/
		int getMouseX();

		/**
		@brief Returns the vertical position of the mouse
		*/
		int getMouseY();

		/**
		@brief Returns the reference to the window renderer
		*/
		SDL_Renderer* getRenderer();

		/**
		@brief Returns the window width
		*/
		int getWidth();

		/**
		@brief Returns the window height
		*/
		int getHeight();

	private:

		/// Window width
		unsigned width;

		/// Window height
		unsigned height;

		/// Window title
		std::string title;

		/// This flag states if the game should run
		bool runGame;

		/// Window to render to
		SDL_Window* window = NULL;

		/// SDL renderer
		SDL_Renderer* renderer = NULL;
	};
}