#include "Engine.h"

#include "Button.h"

int main(int argc, char* args[])
{
	Engine e;
	e.show();

	e.~Engine();

	return 0;
}