#include "Engine.h"
#include "Scene.h"

#include "MainMenuScene.h"
#include "GameScene.h"

#define WINDOW_WIDTH 800
#define WINDOW_HEIGHT 600

Engine::Engine() : SDL::Window(WINDOW_WIDTH, WINDOW_HEIGHT, "Block Chores")
{
	switchScene(MAINMENU);
}

Engine::~Engine()
{
}

void Engine::update()
{
	if (currentScene) {
		currentScene->update();
	}
}

void Engine::draw()
{
	if (currentScene) {
		currentScene->draw();
	}
}

void Engine::mouseButtonDown(Uint8 button)
{
	if (currentScene) {
		currentScene->mouseButtonDown(button);
	}
}

void Engine::switchScene(SceneID sceneID)
{
	switch (sceneID) {
	case MAINMENU:
		currentScene = std::make_shared<MainMenuScene>(this);
		currentSceneID = sceneID;
		break;
	case GAME:
		currentScene = std::make_shared<GameScene>(this);
		currentSceneID = sceneID;
		break;
	}
}
