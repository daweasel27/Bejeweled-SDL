#pragma once

#include "Scene.h"
#include "Image.h"
#include "Sound.h"
#include "Button.h"

class Engine;

class MainMenuScene : public Scene {

public:
	/*
	@brief Create a new MainMenuScene
	*/
	MainMenuScene(Engine* engine);

	/*
	@brief Destroys the MainMenuScene
	*/
	~MainMenuScene();

	/*
	@brief Controls the menu logic and Scene transitions
	*/
	void update();

	/*
	@brief Draws the main menu
	*/
	void draw();

	/*
	@brief Handles the mouse input
	*/
	void mouseButtonDown(Uint8 button);

private:
	///The background image
	SDL::Image backgroundImg;

	///The "Play" button
	std::shared_ptr<Button> playButton;

	///The intro sound
	SDL::Sound introSound;

};
