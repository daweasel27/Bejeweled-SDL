#pragma once

#include <SDL.h>

class Engine;

/**
Scene

Base class for all the game scenes
*/
class Scene {
protected:
	/**
	@brief Reference to the Engine class
	**/
	Engine* engine;

public:
	/**
	@brief Default constructor
	*/
	Scene(Engine* engine);

	/**
	@brief The destructor is virtual and has to be defined in each Scene
	*/
	virtual ~Scene();

	/**
	@brief Handles the game logic at every frame. Must be overloaded
	*/
	virtual void update() = 0;

	/**
	@brief Handles the graphic drawing at every frame. Must be overloaded
	*/
	virtual void draw() = 0;

	/**
	@brief Event for the mouse button down
	*/
	virtual void mouseButtonDown(Uint8) { }
};