#pragma once

#include <array>
#include <queue>

#include "Image.h"
#include "Block.h"
#include "Sound.h"

#define BOARD_WIDTH 17
#define BOARD_HEIGHT 10
#define INITIAL_BOARD_WIDTH 8
#define INITIAL_BOARD_HEIGHT 10

#define GAME_DRAW_OFFSET_X 120
#define GAME_DRAW_OFFSET_Y 126

class Engine;

enum GameState {
	IDLE,
	DESTROY_BLOCKS,
	DROP_BLOCKS,
	COMPACT_BLOCKS,
	PUSH_BLOCKS,
	LEVEL_UP,
	GENERATE_GRID,
	GAME_OVER
};

class GameGrid
{
public:
	/**
	@brief The Game Grid constructor
	@param engine The engine to draw to
	*/
	GameGrid(Engine* e);
	~GameGrid();

	/**
	@brief Handles the grid logic. Called every tick
	*/
	void update();

	/**
	@brief Draws the grid. Called every tick
	*/
	void draw();

	/**
	@brief Adds the push state to the state queue
	@description in practice, it pushes a new column from the right
	*/
	void push();

	/**
	@brief Handles the click on a Block
	@param x The x coordinate of the Block
	@param y The y coordinate of the Block
	*/
	int handleBlockClick(int x, int y);

	/**
	@brief Adds the level up state to the state queue
	@In practive, it will drop the board and shift a new one
	*/
	void levelUp();

	/**
	@brief Returns the boards state
	*/
	GameState getState();

	/**
	@brief Resets the board
	*/
	void reset();

private:
	std::array< Block, BOARD_WIDTH * BOARD_HEIGHT> blocks;

	queue <GameState> stateQueue;

	GameState currentState;

	///Images
	SDL::Image trayImg;
	SDL::Image blockRedImg;
	SDL::Image blockGreenImg;
	SDL::Image blockBlueImg;
	SDL::Image blockGreyImg;
	SDL::Image blockOrangeImg;

	///Sounds
	SDL::Sound gameOverSound;
	SDL::Sound levelUpSound;
	SDL::Sound destroyBlocksSound;
	SDL::Sound pushSound;
	SDL::Sound generateBoardSound;

	SDL::Image selector;

	bool updating;

	/**
	@brief Loads the required resources
	*/
	void loadResources();

	/**
	@brief Returns if the grid is updating
	*/
	bool isUpdating();

	/**
	@brief Generates the grid
	*/
	void generateGrid();

	/**
	@brief Cleans the grid
	*/
	void cleanGrid();

	/**
	@brief Handles game over
	*/
	void gameOver();

	/**
	@brief Gets the Block Img by type
	@param type The Block type
	*/
	SDL::Image getImgByType(int type);

	/**
	@brief Checks adjacents of the same type and marks them for destruction
	@param x The x coordinate of the block
	@param y The y coordinate of the block
	@out returns the number of adjacents found
	*/
	int checkSameTypeAdjacents(int x, int y);

	/**
	@brief Destroys the blocks marked for destruction
	*/
	int destroyBlocks();

	/**
	@brief Drops the blocks after destruction
	*/
	void dropBlocks();

	/**
	@brief Drops the blocks of a column
	@param x The column index
	*/
	void dropBlocksOfColumn(int x);

	/**
	@brief Compacts the grid to the right if there's empty columns
	*/
	void compactBlocks();

	/**
	@brief Checks if the column is empty
	@param x The column index
	*/
	bool checkEmptyColumn(int x);

	/**
	@brief Moves a column between two indexs, given a side to move to
	@param destIndex The destination index
	@param origIndex The origin index
	@param side The side to move to (left or right)
	*/
	void moveColumn(int destIndex, int origIndex, string side);

	/**
	@brief Generates a new column on the right most position
	*/
	void generateNewColumn();

	/**
	@brief Checks next State in the state queue and processes it
	*/
	void handleState();

	/**
	@brief Handles the level up sequence
	*/
	void levelUpGrid();

	/**
	@brief Pushes the grid one position to the left
	*/
	void pushGrid();

	Engine* engine;
};
