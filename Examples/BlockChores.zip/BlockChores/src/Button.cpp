#include "Button.h"
#include "Engine.h"

Button::Button(Engine * e, std::string imgFilePath): engine(e)
{
	// Init the button image
	img.setWindow(engine);
	img.setPath(imgFilePath);

}

Button::~Button()
{
}

void Button::draw()
{
	img.draw(posX, posY, 1);
}

bool Button::isInside(int x, int y)
{
	if (x >= posX && x <= posX + img.getWidth()
		&& y >= posY && y <= posY + img.getHeight())
	{
		return true;
	}
	else {
		return false;
	}
}

void Button::centerHorizontally(int windowWidth)
{
	posX = windowWidth / 2 - img.getWidth() / 2;
}

void Button::setPosition(int x, int y)
{
	posX = x;
	posY = y;
}

int Button::getHeight()
{
	return img.getHeight();
}

int Button::getWidth()
{
	return img.getWidth();
}
