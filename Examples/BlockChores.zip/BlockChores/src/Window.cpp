#include "Window.h"

#include <iostream>
#include <stdexcept>

using namespace std;

SDL::Window::Window(unsigned width, unsigned height, std::string title):
	width(width), height(height), title(title)
{
	//Start SDL
	if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO) < 0) {
		throw std::runtime_error(SDL_GetError());
	}

	// Set texture filtering to linear
	if (!SDL_SetHint(SDL_HINT_RENDER_SCALE_QUALITY, "1"))
	{
		cerr << "Warning: Linear texture filtering not enabled!" << endl;
	}

	//Initialize PNG loading
	int imgFlags = IMG_INIT_PNG;
	if (!(IMG_Init(imgFlags) & imgFlags))
	{
		throw std::runtime_error(IMG_GetError());
	}

	//Initialize SDL_TTF

	TTF_Init();

	//Initialize SDL_mixer
	if (Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 2048) < 0)
	{
		throw std::runtime_error(Mix_GetError());
	}

	// Create window
	window = SDL_CreateWindow(title.c_str(),
		SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED,
		width, height,
		SDL_WINDOW_SHOWN);

	// If window could not be created, throw an error
	if (window == NULL)
	{
		throw std::runtime_error(SDL_GetError());
	}

	// Create a renderer for the Window
	renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);

	// If rendered could not be created, throw an error
	if (renderer == NULL)
	{
		throw std::runtime_error(SDL_GetError());
	}

	// Initialize renderer color
	SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
}

SDL::Window::~Window()
{
	SDL_DestroyRenderer(renderer);
	SDL_DestroyWindow(window);
	renderer = NULL;
	window = NULL;

	// Quit SDL
	Mix_Quit();
	IMG_Quit();
	SDL_Quit();
}

void SDL::Window::show()
{
	// Show the window
	SDL_ShowWindow(window);

	runGame = true;

	// Event to catch
	SDL_Event e;

	// Game loop
	while (runGame) {

		// Event loop
		while (SDL_PollEvent(&e))
		{
			switch (e.type)
			{

			case SDL_QUIT:
				return;

			case SDL_MOUSEBUTTONDOWN:
				mouseButtonDown(e.button.button);
				break;

			}

		}

		// Handle logic
		update();

		// Render the background clear
		SDL_RenderClear(renderer);

		// Handle drawing
		draw();

		//DRAW

		// Update the screen
		SDL_RenderPresent(renderer);
	}
}

void SDL::Window::close()
{
	runGame = false;
}

int SDL::Window::getMouseX()
{
	int x;
	SDL_GetMouseState(&x, NULL);

	return x;
}

int SDL::Window::getMouseY()
{
	int y;
	SDL_GetMouseState(NULL, &y);

	return y;
}

SDL_Renderer * SDL::Window::getRenderer()
{
	return renderer;
}

int SDL::Window::getWidth()
{
	return width;
}

int SDL::Window::getHeight()
{
	return height;
}
