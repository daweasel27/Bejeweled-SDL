#pragma once
#include "Image.h"

#define BLOCK_DRAW_SIZE 40

enum BlockSprite
{
	BLOCK_SPRITE_MOUSE_OUT = 0,
	BLOCK_SPRITE_MOUSE_OVER = 1
};

enum BlockType
{
	BLOCK_RED = 0,
	BLOCK_GREEN = 1,
	BLOCK_BLUE = 2,
	BLOCK_GREY = 3,
	BLOCK_ORANGE = 4,
};

enum AnimationOrientation {
	HORIZONTAL,
	VERTICAL
};

class Block
{
public:
	/**
	@brief The block constructor
	@param t The Block type
	*/
	Block();
	~Block();

	/**
	@brief Handles the Block logic. Calls for animations
	*/
	void update();

	/**
	@brief Draws the block
	@param offsetX The offset in X
	@param offsetY The offset in Y
	*/
	void draw(int offsetX, int offsetY);

	/**
	@brief Returns the block type
	*/
	int getType();

	/**
	@brief Sets the block type
	@param t The Block type
	*/
	void setType(int t);

	/**
	@brief Sets top left position
	@param x The position in x
	@param y Thew position in y
	*/
	void setPosition(float x, float y);

	/**
	@brief Returns if the Block is marked to update
	*/
	bool toUpdate();

	/**
	@brief Increments the update positions value
	*/
	void incrementUpdatePositions();

	/**
	@brief sets the update positions value
	@param drop The value of the drop to copy to update positions
	*/
	void setUpdatePositions(int drop);

	/**
	@brief Returns the update positions value
	*/
	int getUpdatePositions();

	/**
	@brief Sets the block to be destroyed
	*/
	void setToDestroy(bool value);

	/**
	@brief Returns if the Block is marked to destroy
	*/
	bool toDestroy();

	/**
	@brief Returns if the block is empty
	*/
	bool isEmpty();

	/**
	@brief Sets the block empty
	*/
	void setEmpty(bool e);

	/**
	@brief sets the block image
	*/
	void setImg(SDL::Image img);

	/**
	@brief Makes the block drop
	@param maxDrop The max amount a block can drop. Used to calculate speed
	@description The block will drop the value of update positions
	*/
	void drop(int maxDrop);

	/**
	@brief Makes the block shift left
	@param origX The origin x position
	@param origY The origin y position
	@param value The amount of positions to shift
	@param maxShift The max amount a block can shift. Used to calculate speed
	*/
	void shiftLeft(int origX, int origY, int value, int maxShift);

	/**
	@brief Makes the block shift right
	@param origX The origin x position
	@param origY The origin y position
	@param value The amount of positions to shift
	@param maxShift The max amount a block can shift. Used to calculate speed
	*/
	void shiftRight(int origX, int origY, int value, int maxShift);

private:
	///Position
	float posX;
	float posY;

	///Draw Position
	float drawPosX;
	float drawPosY;

	///Animation Positions
	float animOrigX;
	float animOrigY;

	float animDestX;
	float animDestY;

	int animMaxMove;
	AnimationOrientation animOrientation;

	int animStartTime;

	int type;

	bool destroy;

	bool updatePosition;

	bool empty;

	///Origin of movement
	int origX;
	int origY;

	///Destination of movement
	int destX;
	int destY;

	///stores how many positions to drop
	int updatePositions;

	///Yhe image of the block
	SDL::Image blockImg;

	/**
	@brief Linear interpolation between the block's original and final positions
	@param f The factor to calculate current position
	*/
	void rectLerp(float f);

	/**
	@brief LAnimates the block
	@param totalTime The animation time
	*/
	bool animate(float totalTime);
};