#include "GameStats.h"
#include "Engine.h"

#include <iostream>

GameStats::GameStats(Engine* e): engine(e)
{


	levelBar.setWindow(engine);
	levelBar.setPath("Assets/Images/progressBar.png");

	pushBar.setWindow(engine);
	pushBar.setPath("Assets/Images/progressBar.png");

	fontUI.setParams(engine, "Assets/Fonts/smallfont.ttf", 18);

	scoreImg = fontUI.renderText(std::to_string(0), { 0, 0, 0, 255 });

	levelImg = fontUI.renderText(std::to_string(1), { 0, 0, 0, 255 });
}

GameStats::~GameStats()
{
}

void GameStats::draw()
{
	//Level bar x337 y17
	//push bar x558 y17
	levelBar.draw(337, 17, 1, levelBarPercentage);

	pushBar.draw(558, 17, 1, pushBarPercentage);

	scoreImg.draw(85, 18, 1);

	levelImg.draw(300, 18, 1);
}

void GameStats::updateScore(int score)
{
	scoreImg = fontUI.renderText(std::to_string(score), { 0, 0, 0, 255 });
}

void GameStats::updateLevel(int level)
{
	levelImg = fontUI.renderText(std::to_string(level), { 0, 0, 0, 255 });
}

void GameStats::updateLevelBar(int score, int prevLevelScore, int nextLevelScore)
{
	float adjustedScore = score - prevLevelScore;
	float adjustedNextLevel = nextLevelScore - prevLevelScore;

	levelBarPercentage = adjustedScore / adjustedNextLevel;

	cerr << "levelbarpercentage: ";
	cerr << levelBarPercentage;
	cerr << "\n";
}

void GameStats::updatePushBar(float pushTime, float actualTime)
{
	pushBarPercentage =  actualTime / pushTime;
}
