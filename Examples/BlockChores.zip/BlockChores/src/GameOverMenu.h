#pragma once

#include "Image.h"
#include "Text.h"
#include "Button.h"

class Engine;

class GameOverMenu
{
public:
	/**
	@brief The game over menu contructor
	@param engine The engine to draw to
	@param lvl The level to show
	@param scr The score to show
	*/
	GameOverMenu(Engine* e, int lvl, int scr);
	~GameOverMenu();

	/**
	@brief Draws the game over menu
	*/
	void draw();

	/**
	@brief Checks if the play again button was pressed
	@param mouseX the mouse X position on the screen
	@param mouseY The mouse Y position on the screen
	*/
	bool playAgainPressed(int mouseX, int mouseY);

private:
	///Images
	SDL::Image backgroundImg;

	SDL::Image scoreImg;

	SDL::Image levelImg;

	///Buttons
	std::shared_ptr<Button> playAgainButton;

	///Fonts
	SDL::Text fontUI;

	Engine* engine;

	/**
	@brief Centers an Image horizontally on the window
	*/
	int centerImgHorizontally(SDL::Image img);

};
