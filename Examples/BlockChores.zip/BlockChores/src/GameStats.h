#pragma once

#include "Image.h"
#include "Text.h"

class Engine;

class GameStats
{
public:
	/**
	@brief The Game stats constuctor
	@engine The engine to draw to
	*/
	GameStats(Engine* e);

	~GameStats();

	/**
	@brief Draws the stats on to the window
	*/
	void draw();

	/**
	@brief Sets the score to the given amount
	@param score The current game score
	*/
	void updateScore(int score);

	/**
	@brief Increases the score by the given amount
	@param level The current game level
	*/
	void updateLevel(int level);

	/**
	@brief Updates the remaining time, the argument is given in seconds
	@param score The current game score
	@param prevLEvelScore The needed score to achieve the current level
	@param nextLevelScore The needed score to achieve the next level
	*/
	void updateLevelBar(int score, int prevLevelScore, int nextLevelScore);

	/**
	@brief Updates the push bar
	@param pushTime Total time for the push
	@param actualTime Time passed since last push
	*/
	void updatePushBar(float pushTime, float actualTime);

private:
	///Images
	SDL::Image scoreImg;
	SDL::Image levelImg;
	SDL::Image levelBar;
	SDL::Image pushBar;

	///Text
	SDL::Text fontUI;

	///The percentages of the progress bars
	float pushBarPercentage;

	float levelBarPercentage;

	Engine* engine;

};
