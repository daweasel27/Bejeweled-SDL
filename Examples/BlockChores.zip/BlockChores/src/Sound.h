#pragma once

#include <string>

#include <SDL_mixer.h>

namespace SDL {

	class Sound
	{
	public:
		/**
		@brief The constructor for Sound
		*/
		Sound();
		~Sound();

		/**
		@brief Sets the path to the sound file
		@param filePath The path to the sound file
		*/
		void setPath(std::string filePath);

		/**
		@brief Plays the Sound
		@param volume The volume of the sound. Default to 1
		@param repeat If the sound should loop. Default to false
		*/
		void play(float volume = 1, bool repeat = false);

		/**
		@brief Stops the sound reprodution
		*/
		void stop();

	private:
		///Pointer to the sound
		Mix_Chunk* sound = nullptr;

	};
}