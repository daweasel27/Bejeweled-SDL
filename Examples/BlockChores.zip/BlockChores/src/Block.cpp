#include "Block.h"


#include <iostream>

Block::Block()
{
	destroy = false;
	updatePosition = false;
	updatePositions = 0;
	empty = false;
}

Block::~Block()
{
}

void Block::update()
{
	float animationSpeed;

	//We calculate the animation speed according to height of the Block and orientation
	switch (animOrientation)
	{
	case HORIZONTAL:
		animationSpeed = 200;
		break;
	case VERTICAL:
		animationSpeed = 100 * (animDestY - animOrigY);
		break;
	default:
		break;
	}

	if (updatePosition) {
		animate(animationSpeed);
	}

}

void Block::draw(int offsetX, int offsetY)
{
	if (!empty) {
		blockImg.draw((int)drawPosX + offsetX, (int)drawPosY + offsetY, 1);
	}
}

int Block::getType()
{
	return type;
}

void Block::setType(int t)
{
	type = t;
}

void Block::setPosition(float x, float y)
{
	posX = x;
	posY = y;

	drawPosX = posX * BLOCK_DRAW_SIZE;
	drawPosY = posY * BLOCK_DRAW_SIZE;
}

bool Block::toUpdate()
{
	return updatePosition;
}

void Block::incrementUpdatePositions()
{
	updatePositions++;
}

void Block::setUpdatePositions(int drop)
{
	updatePositions = drop;
}

int Block::getUpdatePositions()
{
	return updatePositions;
}

void Block::setToDestroy(bool value)
{
	destroy = value;
}

bool Block::toDestroy()
{
	return destroy;
}

bool Block::isEmpty()
{
	return empty;
}

void Block::setEmpty(bool e)
{
	empty = e;
}

void Block::setImg(SDL::Image img)
{
	blockImg = img;
}

void Block::drop(int maxDrop)
{
	animOrientation = VERTICAL;
	updatePosition = true;
	animOrigX = posX;
	animOrigY = posY;
	animDestX = posX;
	animDestY = posY + updatePositions;

	animMaxMove = maxDrop;

	animStartTime = SDL_GetTicks();
}

void Block::shiftLeft(int origX, int origY, int value, int maxShift)
{
	animOrientation = HORIZONTAL;
	updatePosition = true;
	animOrigX = (float)origX;
	animOrigY = (float)origY;
	animDestX = (float)origX - value;
	animDestY = (float)origY;

	animMaxMove = maxShift;

	animStartTime = SDL_GetTicks();
}

void Block::shiftRight(int origX, int origY, int value, int maxShift)
{
	animOrientation = HORIZONTAL;
	updatePosition = true;
	animOrigX = (float)origX;
	animOrigY = (float)origY;
	animDestX = (float)origX + value;
	animDestY = (float)origY;

	animMaxMove = maxShift;

	animStartTime = SDL_GetTicks();
}

void Block::rectLerp(float f)
{
	float t = 1.0f - f;

	setPosition(animOrigX == animDestX ? animOrigX : (float)animOrigX * t + (float)animDestX * f,
		animOrigY == animDestY ? animOrigY :(float)animOrigY * t + (float)animDestY * f);

}

bool Block::animate(float totalTime)
{
	int currentTime = SDL_GetTicks();
	if (currentTime > animStartTime + totalTime) {
		// if the animation is complete
		//Reinforce the final position
		setPosition(animDestX, animDestY);
		updatePosition = false;
		updatePositions = 0;

		return true;
	}
	else {
		// animation is incomplete - interpolate coordinates
		// calculate current animation percentage - in range [0; 1]
		float factor = ((float)(currentTime - animStartTime)) / totalTime;

		rectLerp(factor);

		return false;
	}
}
