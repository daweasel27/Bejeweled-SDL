#include "MainMenuScene.h"

#include "Engine.h"

MainMenuScene::MainMenuScene(Engine* engine) : Scene(engine)
{
	//Init background
	backgroundImg.setWindow(engine);
	backgroundImg.setPath("Assets/Images/menuBackground.png");

	//Init Play button
	//playButton = new Button(engine, "Assets/Images/playButton.png");
	playButton = std::make_shared<Button>(engine, "Assets/Images/playButton.png");
	playButton->setPosition(0, engine->getHeight() - playButton->getHeight() - 20);
	playButton->centerHorizontally(engine->getWidth());

	//Init Intro sound
	introSound.setPath("Assets/Sounds/intro.wav");
	introSound.play();

}

MainMenuScene::~MainMenuScene()
{
}

void MainMenuScene::update()
{
}

void MainMenuScene::draw()
{
	//Draw background
	backgroundImg.draw(0, 0, 1);

	//Draw Play Button
	playButton->draw();
}

void MainMenuScene::mouseButtonDown(Uint8 button)
{
	if (button == SDL_BUTTON_LEFT)
	{
		// Get mouse position
		int y = engine->getMouseY();
		int x = engine->getMouseX();

		// Check if it's inside the "play" button
		if (playButton->isInside(x, y))
		{
			// Starts the game
			engine->switchScene(GAME);
		}
	}
}
