<p align="center">
  <img src="http://i.imgur.com/PeVP7v3.png" />
</p>
GemSwapper is a Bejeweled clone using C++ and SDL. I did it so I could expand my knowledge and practice of C++ and to get to know SDL.

It still needs a lot of work and I plan to add other features in the future.
