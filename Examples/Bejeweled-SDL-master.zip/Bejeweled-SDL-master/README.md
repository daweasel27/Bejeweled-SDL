Bejeweled clone made in SDL

The executable is located at bin/Bejeweled.exe (Windows only).

CONTROLS:
- Mouse click/drag - select gems
- R - randomize board
- S - save board
- L - load board

FEATURES:
- Bejeweled
- Animations
- Simplified board customization (by modifying the consts in src/Board.cpp)
