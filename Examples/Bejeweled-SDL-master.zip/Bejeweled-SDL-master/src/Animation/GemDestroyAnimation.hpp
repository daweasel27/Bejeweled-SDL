#pragma once

#include "../Animation.hpp"

class GemDestroyAnimation : public Animation
{
public:
	GemDestroyAnimation(Pair);
};