#pragma once

#include "../Animation.hpp"
#include "../Pair.hpp"

class GemSwitchAnimation : public Animation
{
public:
	GemSwitchAnimation(Pair, Pair);
};