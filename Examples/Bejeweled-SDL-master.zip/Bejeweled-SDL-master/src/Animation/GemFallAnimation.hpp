#pragma once

#include "../Animation.hpp"
#include "../Pair.hpp"

class GemFallAnimation : public Animation
{
public:
	GemFallAnimation(Pair, Pair);
};