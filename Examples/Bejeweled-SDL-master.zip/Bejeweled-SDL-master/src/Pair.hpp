#pragma once

struct Pair
{
	int x, y;
	
	Pair() {}
	Pair(int x, int y) : x(x), y(y) {}
};